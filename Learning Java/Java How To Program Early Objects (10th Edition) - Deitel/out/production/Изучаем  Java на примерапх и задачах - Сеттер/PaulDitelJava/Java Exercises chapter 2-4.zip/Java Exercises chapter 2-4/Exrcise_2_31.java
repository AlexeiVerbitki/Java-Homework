package PaulDitelJava.ch02;

public class Exrcise_2_31 {
    public static void main(String[] args) {
        System.out.printf("number\tsquare\tcube\n");
        int x = 0;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 1;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 2;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 3;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 4;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 5;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 6;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 7;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 8;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 9;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);
        x = 10;
        System.out.printf("%d\t%d\t%d\n", x, x*x, x*x*x);


    }
}
