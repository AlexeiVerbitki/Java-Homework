//package PaulDitelJava.ch03.Exercise_Chapter_3;
//
//public class Exercise_3_14_Date {
//    int day;
//    int month;
//    int year;
//
//
//
//    public int getYear() {
//        return year;
//    }
//
//    public void setYear(int year) {
//        if (1900 <= year && year <=2017)
//            this.year = year;
//    }
//    public int getMonth() {
//        return month;
//    }
//
//    public void setMonth(int month) {
//        if (month > 12)
//            System.out.printf("The month can't be more than 12");
//        else if ()
//        this.month = month;
//    }
//    public int getDay() {
//        return day;
//    }
//
//    public void setDay(int day) {
//        this.day = day;
//    }
//
//}
